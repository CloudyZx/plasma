# PlasmaRAT
Remote Access Trojan(RAT), Miner, DDoS
#### All responsibilities are at your own risk.
#### Please use it only for research purposes.
# Feature
* Remote Desktop
* Keylogger
* DDoS
* Miner
* Startup Control
* Network Connection View
* Native Method Controller

